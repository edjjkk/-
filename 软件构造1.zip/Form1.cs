﻿using System;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // 获取输入值
            double num1, num2, result = 0;
            string operatorSymbol = cmbOperator.SelectedItem?.ToString();

            // 验证输入是否为数字
            if (!double.TryParse(txtNumber1.Text, out num1) || !double.TryParse(txtNumber2.Text, out num2))
            {
                MessageBox.Show("请输入有效的数字！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 检查运算符是否为空
            if (string.IsNullOrEmpty(operatorSymbol))
            {
                MessageBox.Show("请选择一个运算符！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 根据运算符执行计算
            try
            {
                switch (operatorSymbol)
                {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "*":
                        result = num1 * num2;
                        break;
                    case "/":
                        if (num2 != 0)
                        {
                            result = num1 / num2;
                        }
                        else
                        {
                            MessageBox.Show("除数不能为零！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        break;
                    default:
                        MessageBox.Show("无效的运算符！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"发生错误: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 显示结果
            lblDisplay.Text = result.ToString();
        }
    }
}