﻿using System.Drawing;

public partial class MainForm : Form
{
    private readonly OrderService _orderService = new OrderService();
    private readonly BindingSource _orderBindingSource = new BindingSource();
    private readonly BindingSource _detailsBindingSource = new BindingSource();

    public MainForm()
    {
        InitializeComponent();
        SetupDataBindings();
        LoadOrders();
    }

    private void SetupDataBindings()
    {
        // 订单列表绑定
        _orderBindingSource.DataSource = typeof(List<Order>);
        dgvOrders.DataSource = _orderBindingSource;
        dgvOrders.AutoGenerateColumns = false;

        // 订单明细列表绑定
        _detailsBindingSource.DataSource = _orderBindingSource;
        _detailsBindingSource.DataMember = "Details";
        dgvOrderDetails.DataSource = _detailsBindingSource;
        dgvOrderDetails.AutoGenerateColumns = false;

        // 设置列
        SetupDataGridViewColumns();
    }

    private void SetupDataGridViewColumns()
    {
        // 订单列表列
        dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "OrderId",
            HeaderText = "订单号",
            Width = 120
        });

        dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "Customer.CustomerName",
            HeaderText = "客户",
            Width = 150
        });

        dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "OrderTime",
            HeaderText = "下单时间",
            Width = 180,
            DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm:ss" }
        });

        dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "TotalAmount",
            HeaderText = "总金额",
            Width = 100,
            DefaultCellStyle = new DataGridViewCellStyle { Format = "C2" }
        });

        // 订单明细列
        dgvOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "Goods.GoodsName",
            HeaderText = "商品名称",
            Width = 150
        });

        dgvOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "Quantity",
            HeaderText = "数量",
            Width = 80
        });

        dgvOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = "Amount",
            HeaderText = "金额",
            Width = 100,
            DefaultCellStyle = new DataGridViewCellStyle { Format = "C2" }
        });
    }

    private void LoadOrders()
    {
        _orderBindingSource.DataSource = _orderService.GetAllOrders();
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        var editForm = new OrderEditForm(null, _orderService);
        if (editForm.ShowDialog() == DialogResult.OK)
        {
            LoadOrders();
        }
    }

    private void btnEdit_Click(object sender, EventArgs e)
    {
        if (_orderBindingSource.Current is Order selectedOrder)
        {
            var editForm = new OrderEditForm(selectedOrder, _orderService);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                LoadOrders();
            }
        }
        else
        {
            MessageBox.Show("请先选择要修改的订单", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (_orderBindingSource.Current is Order selectedOrder)
        {
            if (MessageBox.Show($"确定要删除订单 {selectedOrder.OrderId} 吗?", "确认删除",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    _orderService.RemoveOrder(selectedOrder.OrderId);
                    LoadOrders();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"删除失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        else
        {
            MessageBox.Show("请先选择要删除的订单", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnQuery_Click(object sender, EventArgs e)
    {
        var queryForm = new QueryForm(_orderService);
        if (queryForm.ShowDialog() == DialogResult.OK)
        {
            _orderBindingSource.DataSource = queryForm.QueryResult;
        }
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
        // 设置窗口布局
        this.WindowState = FormWindowState.Maximized;
        this.MinimumSize = new Size(800, 600);
    }

    private void MainForm_SizeChanged(object sender, EventArgs e)
    {
        // 响应式布局调整
        splitContainer1.SplitterDistance = this.ClientSize.Height / 2;
    }
}