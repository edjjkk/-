﻿public partial class QueryForm : Form
{
    private readonly OrderService _orderService;
    public List<Order> QueryResult { get; private set; }

    public QueryForm(OrderService orderService)
    {
        InitializeComponent();
        _orderService = orderService;
    }

    private void btnQuery_Click(object sender, EventArgs e)
    {
        try
        {
            if (rbOrderId.Checked)
            {
                QueryResult = _orderService.QueryByOrderId(txtKeyword.Text);
            }
            else if (rbCustomer.Checked)
            {
                QueryResult = _orderService.QueryByCustomer(txtKeyword.Text);
            }
            else if (rbGoodsName.Checked)
            {
                QueryResult = _orderService.QueryByGoodsName(txtKeyword.Text);
            }
            else if (rbAmountRange.Checked)
            {
                decimal min = decimal.Parse(txtMinAmount.Text);
                decimal max = decimal.Parse(txtMaxAmount.Text);
                QueryResult = _orderService.QueryByAmountRange(min, max);
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"查询失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void rbAmountRange_CheckedChanged(object sender, EventArgs e)
    {
        txtKeyword.Enabled = !rbAmountRange.Checked;
        txtMinAmount.Enabled = rbAmountRange.Checked;
        txtMaxAmount.Enabled = rbAmountRange.Checked;
    }
}