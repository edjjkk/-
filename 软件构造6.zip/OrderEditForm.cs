﻿public partial class OrderEditForm : Form
{
    private readonly Order _order;
    private readonly OrderService _orderService;
    private readonly BindingSource _detailsBindingSource = new BindingSource();
    private readonly List<Goods> _availableGoods = new List<Goods>();

    public OrderEditForm(Order order, OrderService orderService)
    {
        InitializeComponent();
        _order = order;
        _orderService = orderService;

        // 初始化可用商品列表
        _availableGoods.AddRange(new[]
        {
            new Goods("G001", "笔记本电脑", 5999m),
            new Goods("G002", "智能手机", 3999m),
            new Goods("G003", "无线耳机", 599m),
            new Goods("G004", "智能手表", 1299m)
        });

        InitializeDataBindings();
        SetupComboBoxes();
        LoadOrderData();
    }

    private void InitializeDataBindings()
    {
        _detailsBindingSource.DataSource = typeof(List<OrderDetails>);
        dgvDetails.DataSource = _detailsBindingSource;

        // 绑定订单基本信息
        txtOrderId.DataBindings.Add("Text", _order, "OrderId", false, DataSourceUpdateMode.OnPropertyChanged);
        txtCustomerName.DataBindings.Add("Text", _order?.Customer, "CustomerName", false, DataSourceUpdateMode.OnPropertyChanged);
    }

    private void SetupComboBoxes()
    {
        cmbGoods.DataSource = _availableGoods;
        cmbGoods.DisplayMember = "GoodsName";
        cmbGoods.ValueMember = "GoodsId";
    }

    private void LoadOrderData()
    {
        if (_order == null)
        {
            // 新建订单
            _order = new Order(GenerateOrderId(), new Customer("", "新客户"));
            dtpOrderTime.Value = DateTime.Now;
        }
        else
        {
            // 编辑现有订单
            dtpOrderTime.Value = _order.OrderTime;
            _detailsBindingSource.DataSource = new List<OrderDetails>(_order.Details);
        }
    }

    private string GenerateOrderId()
    {
        return $"ORD-{DateTime.Now:yyyyMMddHHmmss}";
    }

    private void btnAddDetail_Click(object sender, EventArgs e)
    {
        if (cmbGoods.SelectedItem is Goods selectedGoods &&
            int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
        {
            var detail = new OrderDetails(selectedGoods, quantity);

            // 检查是否已存在相同商品的明细
            if (_detailsBindingSource.List.Cast<OrderDetails>().Any(d => d.Goods.Equals(selectedGoods)))
            {
                MessageBox.Show("该商品已存在于订单明细中", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _detailsBindingSource.Add(detail);
            txtQuantity.Text = "1";
        }
        else
        {
            MessageBox.Show("请选择商品并输入有效的数量", "输入错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnRemoveDetail_Click(object sender, EventArgs e)
    {
        if (dgvDetails.CurrentRow?.DataBoundItem is OrderDetails selectedDetail)
        {
            _detailsBindingSource.Remove(selectedDetail);
        }
    }

    private void btnOK_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtOrderId.Text))
        {
            MessageBox.Show("订单号不能为空", "输入错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
        {
            MessageBox.Show("客户名称不能为空", "输入错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (_detailsBindingSource.Count == 0)
        {
            MessageBox.Show("订单必须至少包含一个明细项", "输入错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // 更新订单数据
        _order.OrderTime = dtpOrderTime.Value;
        _order.Customer.CustomerName = txtCustomerName.Text;

        // 更新订单明细
        _order.Details.Clear();
        foreach (OrderDetails detail in _detailsBindingSource.List)
        {
            _order.Details.Add(detail);
        }

        try
        {
            if (_orderService.GetAllOrders().Any(o => o.OrderId == _order.OrderId))
            {
                _orderService.UpdateOrder(_order);
            }
            else
            {
                _orderService.AddOrder(_order);
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"保存失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.DialogResult = DialogResult.Cancel;
        this.Close();
    }
}