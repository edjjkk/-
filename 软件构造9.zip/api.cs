﻿// Controllers/OrdersController.cs
using System.Runtime.InteropServices;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
    {
        _orderService = orderService;
        _logger = logger;
    }

    [HttpGet]
    public ActionResult<IEnumerable<OrderDto>> GetAll()
    {
        try
        {
            return Ok(_orderService.GetAllOrders());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all orders");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("{orderId}")]
    public ActionResult<OrderDto> GetById(string orderId)
    {
        try
        {
            var order = _orderService.GetOrderById(orderId);
            return Ok(order);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error getting order {orderId}");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPost]
    public ActionResult<OrderDto> Create([FromBody] CreateOrderDto createDto)
    {
        try
        {
            var order = _orderService.CreateOrder(createDto);
            return CreatedAtAction(nameof(GetById), new { orderId = order.OrderId }, order);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating order");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPatch("{orderId}/status")]
    public ActionResult<OrderDto> UpdateStatus(string orderId, [FromBody] UpdateOrderStatusDto updateDto)
    {
        try
        {
            var order = _orderService.UpdateOrderStatus(orderId, updateDto);
            return Ok(order);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating status for order {orderId}");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpDelete("{orderId}")]
    public IActionResult Delete(string orderId)
    {
        try
        {
            _orderService.DeleteOrder(orderId);
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error deleting order {orderId}");
            return StatusCode(500, "Internal server error");
        }
    }
}