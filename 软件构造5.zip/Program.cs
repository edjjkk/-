﻿class Program
{
    static OrderService orderService = new OrderService();

    static void Main(string[] args)
    {
        bool exit = false;
        while (!exit)
        {
            Console.WriteLine("\n订单管理系统");
            Console.WriteLine("1. 添加订单");
            Console.WriteLine("2. 删除订单");
            Console.WriteLine("3. 修改订单");
            Console.WriteLine("4. 查询订单");
            Console.WriteLine("5. 显示所有订单");
            Console.WriteLine("6. 排序订单");
            Console.WriteLine("7. 导出订单到文件");
            Console.WriteLine("8. 从文件导入订单");
            Console.WriteLine("0. 退出");
            Console.Write("请选择操作: ");

            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                try
                {
                    switch (choice)
                    {
                        case 1:
                            AddOrder();
                            break;
                        case 2:
                            RemoveOrder();
                            break;
                        case 3:
                            UpdateOrder();
                            break;
                        case 4:
                            QueryOrders();
                            break;
                        case 5:
                            DisplayAllOrders();
                            break;
                        case 6:
                            SortOrders();
                            break;
                        case 7:
                            ExportOrders();
                            break;
                        case 8:
                            ImportOrders();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("无效的选择，请重新输入。");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"发生错误: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("无效的输入，请输入数字。");
            }
        }
    }

    static void AddOrder()
    {
        Console.Write("输入订单号: ");
        string orderId = Console.ReadLine();

        Console.Write("输入客户ID: ");
        string customerId = Console.ReadLine();

        Console.Write("输入客户名称: ");
        string customerName = Console.ReadLine();

        Customer customer = new Customer(customerId, customerName);
        Order order = new Order(orderId, customer);

        bool addMore = true;
        while (addMore)
        {
            Console.Write("输入商品ID: ");
            string goodsId = Console.ReadLine();

            Console.Write("输入商品名称: ");
            string goodsName = Console.ReadLine();

            Console.Write("输入商品单价: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.Write("输入商品数量: ");
            int quantity = int.Parse(Console.ReadLine());

            Goods goods = new Goods(goodsId, goodsName, price);
            OrderDetails detail = new OrderDetails(goods, quantity);

            try
            {
                order.AddDetails(detail);
                Console.WriteLine("订单明细添加成功。");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"添加失败: {ex.Message}");
            }

            Console.Write("是否继续添加商品? (y/n): ");
            addMore = Console.ReadLine().ToLower() == "y";
        }

        try
        {
            orderService.AddOrder(order);
            Console.WriteLine("订单添加成功。");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"添加失败: {ex.Message}");
        }
    }

    static void RemoveOrder()
    {
        Console.Write("输入要删除的订单号: ");
        string orderId = Console.ReadLine();

        try
        {
            orderService.RemoveOrder(orderId);
            Console.WriteLine("订单删除成功。");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"删除失败: {ex.Message}");
        }
    }

    static void UpdateOrder()
    {
        Console.Write("输入要修改的订单号: ");
        string orderId = Console.ReadLine();

        var existingOrders = orderService.QueryByOrderId(orderId);
        if (existingOrders.Count == 0)
        {
            Console.WriteLine("订单不存在。");
            return;
        }

        Console.WriteLine("找到订单:");
        Console.WriteLine(existingOrders[0]);

        Console.Write("输入新客户ID: ");
        string customerId = Console.ReadLine();

        Console.Write("输入新客户名称: ");
        string customerName = Console.ReadLine();

        Customer customer = new Customer(customerId, customerName);
        Order updatedOrder = new Order(orderId, customer);

        bool addMore = true;
        while (addMore)
        {
            Console.Write("输入商品ID: ");
            string goodsId = Console.ReadLine();

            Console.Write("输入商品名称: ");
            string goodsName = Console.ReadLine();

            Console.Write("输入商品单价: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.Write("输入商品数量: ");
            int quantity = int.Parse(Console.ReadLine());

            Goods goods = new Goods(goodsId, goodsName, price);
            OrderDetails detail = new OrderDetails(goods, quantity);

            try
            {
                updatedOrder.AddDetails(detail);
                Console.WriteLine("订单明细添加成功。");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"添加失败: {ex.Message}");
            }

            Console.Write("是否继续添加商品? (y/n): ");
            addMore = Console.ReadLine().ToLower() == "y";
        }

        try
        {
            orderService.UpdateOrder(updatedOrder);
            Console.WriteLine("订单修改成功。");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"修改失败: {ex.Message}");
        }
    }

    static void QueryOrders()
    {
        Console.WriteLine("查询选项:");
        Console.WriteLine("1. 按订单号查询");
        Console.WriteLine("2. 按商品名称查询");
        Console.WriteLine("3. 按客户查询");
        Console.WriteLine("4. 按金额范围查询");
        Console.Write("请选择查询方式: ");

        if (int.TryParse(Console.ReadLine(), out int queryChoice))
        {
            List<Order> result = new List<Order>();
            switch (queryChoice)
            {
                case 1:
                    Console.Write("输入订单号(或部分): ");
                    string orderId = Console.ReadLine();
                    result = orderService.QueryByOrderId(orderId);
                    break;
                case 2:
                    Console.Write("输入商品名称(或部分): ");
                    string goodsName = Console.ReadLine();
                    result = orderService.QueryByGoodsName(goodsName);
                    break;
                case 3:
                    Console.Write("输入客户名称(或部分): ");
                    string customerName = Console.ReadLine();
                    result = orderService.QueryByCustomer(customerName);
                    break;
                case 4:
                    Console.Write("输入最小金额: ");
                    decimal minAmount = decimal.Parse(Console.ReadLine());
                    Console.Write("输入最大金额: ");
                    decimal maxAmount = decimal.Parse(Console.ReadLine());
                    result = orderService.QueryByAmountRange(minAmount, maxAmount);
                    break;
                default:
                    Console.WriteLine("无效的选择。");
                    return;
            }

            if (result.Count == 0)
            {
                Console.WriteLine("没有找到匹配的订单。");
            }
            else
            {
                Console.WriteLine($"找到 {result.Count} 个订单:");
                foreach (var order in result)
                {
                    Console.WriteLine(order);
                    Console.WriteLine("----------------------");
                }
            }
        }
        else
        {
            Console.WriteLine("无效的输入。");
        }
    }

    static void DisplayAllOrders()
    {
        var allOrders = orderService.GetAllOrders();
        if (allOrders.Count == 0)
        {
            Console.WriteLine("没有订单记录。");
        }
        else
        {
            Console.WriteLine($"共有 {allOrders.Count} 个订单:");
            foreach (var order in allOrders)
            {
                Console.WriteLine(order);
                Console.WriteLine("======================");
            }
        }
    }

    static void SortOrders()
    {
        Console.WriteLine("排序选项:");
        Console.WriteLine("1. 按订单号排序(默认)");
        Console.WriteLine("2. 按总金额排序");
        Console.WriteLine("3. 按下单时间排序");
        Console.WriteLine("4. 自定义排序");
        Console.Write("请选择排序方式: ");

        if (int.TryParse(Console.ReadLine(), out int sortChoice))
        {
            switch (sortChoice)
            {
                case 1:
                    orderService.SortOrders();
                    Console.WriteLine("已按订单号排序。");
                    break;
                case 2:
                    orderService.SortOrders((o1, o2) => o1.TotalAmount.CompareTo(o2.TotalAmount));
                    Console.WriteLine("已按总金额排序。");
                    break;
                case 3:
                    orderService.SortOrders((o1, o2) => o1.OrderTime.CompareTo(o2.OrderTime));
                    Console.WriteLine("已按下单时间排序。");
                    break;
                case 4:
                    Console.Write("输入自定义排序字段(OrderId/TotalAmount/OrderTime): ");
                    string field = Console.ReadLine();
                    switch (field.ToLower())
                    {
                        case "orderid":
                            orderService.SortOrders((o1, o2) => o1.OrderId.CompareTo(o2.OrderId));
                            break;
                        case "totalamount":
                            orderService.SortOrders((o1, o2) => o1.TotalAmount.CompareTo(o2.TotalAmount));
                            break;
                        case "ordertime":
                            orderService.SortOrders((o1, o2) => o1.OrderTime.CompareTo(o2.OrderTime));
                            break;
                        default:
                            Console.WriteLine("无效的排序字段。");
                            return;
                    }
                    Console.WriteLine($"已按{field}排序。");
                    break;
                default:
                    Console.WriteLine("无效的选择。");
                    break;
            }
        }
        else
        {
            Console.WriteLine("无效的输入。");
        }
    }

    static void ExportOrders()
    {
        Console.Write("输入导出文件名(如 orders.xml): ");
        string fileName = Console.ReadLine();

        try
        {
            orderService.ExportToFile(fileName);
            Console.WriteLine($"订单已成功导出到 {fileName}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"导出失败: {ex.Message}");
        }
    }

    static void ImportOrders()
    {
        Console.Write("输入导入文件名(如 orders.xml): ");
        string fileName = Console.ReadLine();

        try
        {
            orderService.ImportFromFile(fileName);
            Console.WriteLine($"订单已成功从 {fileName} 导入");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"导入失败: {ex.Message}");
        }
    }
}