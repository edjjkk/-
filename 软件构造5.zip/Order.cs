﻿using System.Text;

public class Order : IComparable<Order>
{
    public string OrderId { get; set; }
    public Customer Customer { get; set; }
    public List<OrderDetails> Details { get; } = new List<OrderDetails>();
    public DateTime OrderTime { get; set; }
    public decimal TotalAmount => Details.Sum(d => d.Amount);

    public Order(string orderId, Customer customer)
    {
        OrderId = orderId;
        Customer = customer;
        OrderTime = DateTime.Now;
    }

    public void AddDetails(OrderDetails detail)
    {
        if (Details.Contains(detail))
        {
            throw new ArgumentException("订单明细已存在，不能重复添加");
        }
        Details.Add(detail);
    }

    public void RemoveDetails(OrderDetails detail)
    {
        if (!Details.Contains(detail))
        {
            throw new ArgumentException("订单明细不存在，无法移除");
        }
        Details.Remove(detail);
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"订单号: {OrderId}, 客户: {Customer.CustomerName}, 下单时间: {OrderTime:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("订单明细:");
        foreach (var detail in Details)
        {
            sb.AppendLine($"  {detail}");
        }
        sb.AppendLine($"总金额: {TotalAmount:C}");
        return sb.ToString();
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }
        Order other = (Order)obj;
        return OrderId == other.OrderId;
    }

    public override int GetHashCode()
    {
        return OrderId.GetHashCode();
    }

    public int CompareTo(Order other)
    {
        if (other == null) return 1;
        return string.Compare(OrderId, other.OrderId, StringComparison.Ordinal);
    }
}