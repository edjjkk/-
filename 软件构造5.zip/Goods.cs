﻿public class Goods
{
    public string GoodsId { get; set; }
    public string GoodsName { get; set; }
    public decimal Price { get; set; }

    public Goods(string goodsId, string goodsName, decimal price)
    {
        GoodsId = goodsId;
        GoodsName = goodsName;
        Price = price;
    }

    public override string ToString()
    {
        return $"商品ID: {GoodsId}, 商品名称: {GoodsName}, 单价: {Price:C}";
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }
        Goods other = (Goods)obj;
        return GoodsId == other.GoodsId;
    }

    public override int GetHashCode()
    {
        return GoodsId.GetHashCode();
    }
}