﻿using System.Xml.Serialization;

public class OrderService
{
    private List<Order> orders = new List<Order>();

    // 添加订单
    public void AddOrder(Order order)
    {
        if (orders.Contains(order))
        {
            throw new ArgumentException("订单已存在，不能重复添加");
        }
        orders.Add(order);
    }

    // 删除订单
    public void RemoveOrder(string orderId)
    {
        var order = orders.FirstOrDefault(o => o.OrderId == orderId);
        if (order == null)
        {
            throw new ArgumentException($"订单号 {orderId} 不存在，无法删除");
        }
        orders.Remove(order);
    }

    // 修改订单
    public void UpdateOrder(Order order)
    {
        var existingOrder = orders.FirstOrDefault(o => o.OrderId == order.OrderId);
        if (existingOrder == null)
        {
            throw new ArgumentException($"订单号 {order.OrderId} 不存在，无法修改");
        }
        orders.Remove(existingOrder);
        orders.Add(order);
    }

    // 查询所有订单
    public List<Order> GetAllOrders()
    {
        return orders.OrderBy(o => o.TotalAmount).ToList();
    }

    // 按订单号查询
    public List<Order> QueryByOrderId(string orderId)
    {
        var query = orders
            .Where(o => o.OrderId.Contains(orderId))
            .OrderBy(o => o.TotalAmount)
            .ToList();
        return query;
    }

    // 按商品名称查询
    public List<Order> QueryByGoodsName(string goodsName)
    {
        var query = orders
            .Where(o => o.Details.Any(d => d.Goods.GoodsName.Contains(goodsName)))
            .OrderBy(o => o.TotalAmount)
            .ToList();
        return query;
    }

    // 按客户查询
    public List<Order> QueryByCustomer(string customerName)
    {
        var query = orders
            .Where(o => o.Customer.CustomerName.Contains(customerName))
            .OrderBy(o => o.TotalAmount)
            .ToList();
        return query;
    }

    // 按金额范围查询
    public List<Order> QueryByAmountRange(decimal minAmount, decimal maxAmount)
    {
        var query = orders
            .Where(o => o.TotalAmount >= minAmount && o.TotalAmount <= maxAmount)
            .OrderBy(o => o.TotalAmount)
            .ToList();
        return query;
    }

    // 排序
    public void SortOrders(Comparison<Order> comparison = null)
    {
        if (comparison == null)
        {
            orders.Sort();
        }
        else
        {
            orders.Sort(comparison);
        }
    }

    // 导出订单到文件
    public void ExportToFile(string fileName)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(List<Order>));
        using (FileStream fs = new FileStream(fileName, FileMode.Create))
        {
            serializer.Serialize(fs, orders);
        }
    }

    // 从文件导入订单
    public void ImportFromFile(string fileName)
    {
        if (!File.Exists(fileName))
        {
            throw new FileNotFoundException("文件不存在");
        }

        XmlSerializer serializer = new XmlSerializer(typeof(List<Order>));
        using (FileStream fs = new FileStream(fileName, FileMode.Open))
        {
            List<Order> importedOrders = (List<Order>)serializer.Deserialize(fs);
            orders.Clear();
            orders.AddRange(importedOrders);
        }
    }
}