﻿public class Customer
{
    public string CustomerId { get; set; }
    public string CustomerName { get; set; }

    public Customer(string customerId, string customerName)
    {
        CustomerId = customerId;
        CustomerName = customerName;
    }

    public override string ToString()
    {
        return $"客户ID: {CustomerId}, 客户名称: {CustomerName}";
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }
        Customer other = (Customer)obj;
        return CustomerId == other.CustomerId;
    }

    public override int GetHashCode()
    {
        return CustomerId.GetHashCode();
    }
}