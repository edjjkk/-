﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

[TestClass]
public class OrderServiceTests
{
    private OrderService orderService;
    private Order testOrder;
    private Customer testCustomer;
    private Goods testGoods;

    [TestInitialize]
    public void Initialize()
    {
        orderService = new OrderService();
        testCustomer = new Customer("C001", "测试客户");
        testGoods = new Goods("G001", "测试商品", 100.0m);
        testOrder = new Order("O001", testCustomer);
        testOrder.AddDetails(new OrderDetails(testGoods, 2));
    }

    [TestMethod]
    public void AddOrder_ShouldAddOrderSuccessfully()
    {
        orderService.AddOrder(testOrder);
        var orders = orderService.GetAllOrders();
        Assert.AreEqual(1, orders.Count);
        Assert.AreEqual("O001", orders[0].OrderId);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void AddOrder_ShouldThrowException_WhenOrderExists()
    {
        orderService.AddOrder(testOrder);
        orderService.AddOrder(testOrder); // 重复添加
    }

    [TestMethod]
    public void RemoveOrder_ShouldRemoveOrderSuccessfully()
    {
        orderService.AddOrder(testOrder);
        orderService.RemoveOrder("O001");
        Assert.AreEqual(0, orderService.GetAllOrders().Count);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void RemoveOrder_ShouldThrowException_WhenOrderNotExists()
    {
        orderService.RemoveOrder("O999"); // 不存在的订单
    }

    [TestMethod]
    public void UpdateOrder_ShouldUpdateOrderSuccessfully()
    {
        orderService.AddOrder(testOrder);

        var updatedOrder = new Order("O001", new Customer("C001", "更新客户"));
        updatedOrder.AddDetails(new OrderDetails(new Goods("G002", "新商品", 50.0m), 3));

        orderService.UpdateOrder(updatedOrder);
        var orders = orderService.GetAllOrders();

        Assert.AreEqual(1, orders.Count);
        Assert.AreEqual("更新客户", orders[0].Customer.CustomerName);
        Assert.AreEqual(150.0m, orders[0].TotalAmount);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentException))]
    public void UpdateOrder_ShouldThrowException_WhenOrderNotExists()
    {
        orderService.UpdateOrder(new Order("O999", testCustomer)); // 不存在的订单
    }

    [TestMethod]
    public void QueryByOrderId_ShouldReturnCorrectOrders()
    {
        orderService.AddOrder(testOrder);
        orderService.AddOrder(new Order("O002", testCustomer));

        var results = orderService.QueryByOrderId("O00");
        Assert.AreEqual(2, results.Count);

        results = orderService.QueryByOrderId("O001");
        Assert.AreEqual(1, results.Count);
        Assert.AreEqual("O001", results[0].OrderId);
    }

    [TestMethod]
    public void QueryByGoodsName_ShouldReturnCorrectOrders()
    {
        orderService.AddOrder(testOrder);

        var order2 = new Order("O002", testCustomer);
        order2.AddDetails(new OrderDetails(new Goods("G002", "其他商品", 200.0m), 1));
        orderService.AddOrder(order2);

        var results = orderService.QueryByGoodsName("测试");
        Assert.AreEqual(1, results.Count);
        Assert.AreEqual("O001", results[0].OrderId);
    }

    [TestMethod]
    public void QueryByCustomer_ShouldReturnCorrectOrders()
    {
        orderService.AddOrder(testOrder);

        var customer2 = new Customer("C002", "其他客户");
        var order2 = new Order("O002", customer2);
        orderService.AddOrder(order2);

        var results = orderService.QueryByCustomer("测试");
        Assert.AreEqual(1, results.Count);
        Assert.AreEqual("O001", results[0].OrderId);
    }

    [TestMethod]
    public void QueryByAmountRange_ShouldReturnCorrectOrders()
    {
        orderService.AddOrder(testOrder); // 200元

        var order2 = new Order("O002", testCustomer);
        order2.AddDetails(new OrderDetails(testGoods, 3)); // 300元
        orderService.AddOrder(order2);

        var results = orderService.QueryByAmountRange(150, 250);
        Assert.AreEqual(1, results.Count);
        Assert.AreEqual("O001", results[0].OrderId);
    }

    [TestMethod]
    public void SortOrders_ShouldSortByOrderIdByDefault()
    {
        var order1 = new Order("O002", testCustomer);
        orderService.AddOrder(order1);

        var order2 = new Order("O001", testCustomer);
        orderService.AddOrder(order2);

        orderService.SortOrders();
        var orders = orderService.GetAllOrders();

        Assert.AreEqual("O001", orders[0].OrderId);
        Assert.AreEqual("O002", orders[1].OrderId);
    }

    [TestMethod]
    public void SortOrders_ShouldSortByCustomComparison()
    {
        var order1 = new Order("O001", testCustomer);
        order1.AddDetails(new OrderDetails(testGoods, 3)); // 300元
        orderService.AddOrder(order1);

        var order2 = new Order("O002", testCustomer);
        order2.AddDetails(new OrderDetails(testGoods, 1)); // 100元
        orderService.AddOrder(order2);

        orderService.SortOrders((o1, o2) => o1.TotalAmount.CompareTo(o2.TotalAmount));
        var orders = orderService.GetAllOrders();

        Assert.AreEqual("O002", orders[0].OrderId);
        Assert.AreEqual("O001", orders[1].OrderId);
    }
}