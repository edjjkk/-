﻿public class OrderDetails
{
    public Goods Goods { get; set; }
    public int Quantity { get; set; }
    public decimal Amount => Goods.Price * Quantity;

    public OrderDetails(Goods goods, int quantity)
    {
        Goods = goods;
        Quantity = quantity;
    }

    public override string ToString()
    {
        return $"{Goods}, 数量: {Quantity}, 小计: {Amount:C}";
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }
        OrderDetails other = (OrderDetails)obj;
        return Goods.Equals(other.Goods);
    }

    public override int GetHashCode()
    {
        return Goods.GetHashCode();
    }
}