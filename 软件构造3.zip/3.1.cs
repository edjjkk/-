﻿using System;
using System.Collections.Generic;

// 定义形状接口
public interface IAreaCalculable
{
    double CalculateArea();
}

// 定义抽象类 Shape
public abstract class Shape : IAreaCalculable
{
    public abstract bool IsValid();
    public abstract double CalculateArea();
}

// 长方形类
public class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override bool IsValid()
    {
        return Width > 0 && Height > 0;
    }

    public override double CalculateArea()
    {
        if (!IsValid())
        {
            throw new InvalidOperationException("Invalid rectangle dimensions.");
        }
        return Width * Height;
    }
}

// 正方形类
public class Square : Shape
{
    public double SideLength { get; set; }

    public Square(double sideLength)
    {
        SideLength = sideLength;
    }

    public override bool IsValid()
    {
        return SideLength > 0;
    }

    public override double CalculateArea()
    {
        if (!IsValid())
        {
            throw new InvalidOperationException("Invalid square dimensions.");
        }
        return SideLength * SideLength;
    }
}

// 三角形类
public class Triangle : Shape
{
    public double SideA { get; set; }
    public double SideB { get; set; }
    public double SideC { get; set; }

    public Triangle(double sideA, double sideB, double sideC)
    {
        SideA = sideA;
        SideB = sideB;
        SideC = sideC;
    }

    public override bool IsValid()
    {
        return SideA > 0 && SideB > 0 && SideC > 0 &&
               SideA + SideB > SideC &&
               SideA + SideC > SideB &&
               SideB + SideC > SideA;
    }

    public override double CalculateArea()
    {
        if (!IsValid())
        {
            throw new InvalidOperationException("Invalid triangle dimensions.");
        }

        // 使用海伦公式计算三角形面积
        double s = (SideA + SideB + SideC) / 2;
        return Math.Sqrt(s * (s - SideA) * (s - SideB) * (s - SideC));
    }
}

// 简单工厂类
public static class ShapeFactory
{
    private static Random random = new Random();

    // 随机创建形状对象
    public static Shape CreateRandomShape()
    {
        int shapeType = random.Next(0, 3); // 随机生成 0、1 或 2

        switch (shapeType)
        {
            case 0:
                double width = random.NextDouble() * 10 + 1; // 生成 1 到 11 之间的随机数
                double height = random.NextDouble() * 10 + 1;
                return new Rectangle(width, height);

            case 1:
                double sideLength = random.NextDouble() * 10 + 1;
                return new Square(sideLength);

            case 2:
                double sideA = random.NextDouble() * 10 + 1;
                double sideB = random.NextDouble() * 10 + 1;
                double sideC = random.NextDouble() * (sideA + sideB - 1) + 1; // 确保三角形合法
                return new Triangle(sideA, sideB, sideC);

            default:
                throw new InvalidOperationException("Invalid shape type.");
        }
    }
}

// 测试程序
class Program
{
    static void Main(string[] args)
    {
        List<Shape> shapes = new List<Shape>();

        // 随机创建 10 个形状对象
        for (int i = 0; i < 10; i++)
        {
            Shape shape = ShapeFactory.CreateRandomShape();
            shapes.Add(shape);
            Console.WriteLine($"Created {shape.GetType().Name} with area: {shape.CalculateArea():F2}");
        }

        // 计算总面积
        double totalArea = 0;
        foreach (var shape in shapes)
        {
            totalArea += shape.CalculateArea();
        }

        Console.WriteLine($"\nTotal area of all shapes: {totalArea:F2}");
    }
}