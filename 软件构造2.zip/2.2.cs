﻿using System;
using System.Linq;

class ArrayStatistics
{
    static void Main()
    {
        // 提示用户输入数组大小
        Console.Write("请输入数组的大小: ");
        if (!int.TryParse(Console.ReadLine(), out int size) || size <= 0)
        {
            Console.WriteLine("输入无效，请输入一个正整数。");
            return;
        }

        // 创建数组
        int[] numbers = new int[size];

        // 提示用户输入数组元素
        for (int i = 0; i < size; i++)
        {
            Console.Write($"请输入第 {i + 1} 个元素: ");
            while (!int.TryParse(Console.ReadLine(), out numbers[i]))
            {
                Console.WriteLine("输入无效，请输入一个整数。");
                Console.Write($"请输入第 {i + 1} 个元素: ");
            }
        }

        // 输出数组
        Console.WriteLine("数组: " + string.Join(", ", numbers));

        // 计算并输出结果
        Console.WriteLine("最大值: " + GetMaxValue(numbers));
        Console.WriteLine("最小值: " + GetMinValue(numbers));
        Console.WriteLine("平均值: " + GetAverageValue(numbers));
        Console.WriteLine("元素总和: " + GetSum(numbers));
    }

    // 计算最大值
    static int GetMaxValue(int[] array)
    {
        return array.Max();
    }

    // 计算最小值
    static int GetMinValue(int[] array)
    {
        return array.Min();
    }

    // 计算平均值
    static double GetAverageValue(int[] array)
    {
        return array.Average();
    }

    // 计算元素总和
    static int GetSum(int[] array)
    {
        return array.Sum();
    }
}