﻿using System;

class PrimeFactors
{
    static void Main()
    {
        // 获取用户输入的数字
        Console.Write("请输入一个正整数: ");
        if (int.TryParse(Console.ReadLine(), out int number) && number > 0)
        {
            Console.WriteLine($"数字 {number} 的素数因子为:");
            PrintPrimeFactors(number);
        }
        else
        {
            Console.WriteLine("输入无效，请输入一个正整数。");
        }
    }

    // 检查一个数是否为素数
    static bool IsPrime(int num)
    {
        if (num < 2)
            return false;

        for (int i = 2; i * i <= num; i++)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }

    // 输出一个数的所有素数因子
    static void PrintPrimeFactors(int num)
    {
        for (int i = 2; i <= num; i++)
        {
            if (num % i == 0 && IsPrime(i))
            {
                Console.WriteLine(i);
                while (num % i == 0)
                {
                    num /= i;
                }
            }
        }
    }
}