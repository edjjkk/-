﻿using System;
using System.Collections.Generic;

class SieveOfEratosthenes
{
    static void Main()
    {
        int limit = 100; // 定义上限为100
        List<int> primes = FindPrimes(limit); // 调用方法找出素数

        Console.WriteLine("2~100以内的素数为:");
        Console.WriteLine(string.Join(", ", primes)); // 输出素数
    }

    // 埃氏筛法实现
    static List<int> FindPrimes(int limit)
    {
        // 创建一个布尔数组，初始值为true，表示所有数都是素数
        bool[] isPrime = new bool[limit + 1];
        for (int i = 2; i <= limit; i++)
        {
            isPrime[i] = true;
        }

        // 从2开始，去掉每个素数的倍数
        for (int p = 2; p * p <= limit; p++)
        {
            if (isPrime[p]) // 如果p是素数
            {
                // 去掉p的倍数
                for (int i = p * p; i <= limit; i += p)
                {
                    isPrime[i] = false;
                }
            }
        }

        // 收集所有素数
        List<int> primes = new List<int>();
        for (int i = 2; i <= limit; i++)
        {
            if (isPrime[i])
            {
                primes.Add(i);
            }
        }

        return primes;
    }
}