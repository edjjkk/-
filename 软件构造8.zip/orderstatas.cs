﻿public enum OrderStatus
{
    New,
    Processing,
    Shipped,
    Delivered,
    Cancelled
}

public class Order
{
    // 原有代码...
    public OrderStatus Status { get; set; } = OrderStatus.New;

    // 更新ToString方法
    public override string ToString()
    {
        return $"订单号: {OrderId}, 客户: {Customer.CustomerName}, 状态: {Status}, 总金额: {TotalAmount:C}";
    }
}