﻿using CETVocabularyApp.Services;
using System.Windows;
using System.Collections.Generic;
using System.Threading.Tasks;
using CETVocabularyApp.Helpers;
using System;



namespace CETVocabularyApp
{
    public partial class MainWindow : Window
    {
        private readonly GoogleAIService _aiService;
        private List<Word> currentWordList;
        private int currentIndex = 0;

        public MainWindow()
        {
            InitializeComponent();
            _aiService = new GoogleAIService();
        }

        private void StartLearning_Click(object sender, RoutedEventArgs e)
        {
            // 加载单词列表
            currentWordList = LoadWordList();
            currentIndex = 0;

            if (currentWordList.Count > 0)
            {
                ShowCurrentWord();
            }
            else
            {
                MessageBox.Show("没有可用的单词数据");
            }
        }

        private async void ShowCurrentWord()
        {
            if (currentIndex >= 0 && currentIndex < currentWordList.Count)
            {
                var currentWord = currentWordList[currentIndex];
                txtWord.Text = currentWord.English;
                txtMeaning.Text = $"{currentWord.Chinese}\n\n例句: {currentWord.Example}";

                // 显示加载状态
                imgMemory.Source = ImageHelper.GetLoadingImage();
                pbLoading.Visibility = Visibility.Visible;

                // 生成图片
                var image = await _aiService.GenerateWordImageAsync(currentWord.English, currentWord.Chinese);

                // 显示结果
                pbLoading.Visibility = Visibility.Collapsed;
                imgMemory.Source = image ?? ImageHelper.GetPlaceholderImage();
            }
            else
            {
                MessageBox.Show("学习完成！");
            }
        }

        private async void TestApi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                pbLoading.Visibility = Visibility.Visible;
                var testResult = await _aiService.GenerateImagePrompt("apple", "苹果");
                pbLoading.Visibility = Visibility.Collapsed;

                MessageBox.Show($"API测试成功！生成的提示：\n\n{testResult}",
                    "测试结果", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                pbLoading.Visibility = Visibility.Collapsed;
                MessageBox.Show($"API测试失败：{ex.Message}",
                    "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 其他方法保持不变...
    }
}